1. Preencha o .env.local baseado no .env.example
2. npm install
3. pm2 start ecosystem.config.js
4. O app rodará no http://localhost:3000